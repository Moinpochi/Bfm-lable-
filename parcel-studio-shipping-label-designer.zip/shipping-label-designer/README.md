# Parcel Studio — Shipping Label Designer

A polished frontend-only shipping label workspace built with HTML, CSS and JavaScript.

## Features

- Responsive dashboard and sidebar navigation
- Manual order entry, editing, searching and deleting
- CSV bulk import with validation and duplicate-reference checks
- Optional Excel import (loads SheetJS from a CDN)
- Standard, branded and COD-focused label templates
- Logo upload and sender profile
- Adjustable accent color, address size, sender details and barcode visibility
- A4 and 100 × 150 mm thermal print layouts
- CSV export and JSON backup/restore
- Browser-local storage

## Run locally

1. Download or clone this repository.
2. Open `index.html` in a modern browser.
3. For best results, use VS Code with the Live Server extension and choose **Open with Live Server**.

Internet access is needed for Google Fonts, Lucide icons, jsPDF (loaded for future extension) and the optional SheetJS Excel parser. CSV import and the core interface work without the Excel parser.

## Publish with GitHub Pages

1. Push these files to the root of a GitHub repository.
2. Open **Settings → Pages**.
3. Under Build and deployment, choose **Deploy from a branch**.
4. Select branch `main` and folder `/(root)`, then save.
5. Wait for deployment and open the URL shown in Pages settings.

## Add your logo

You can upload your logo from **Business settings → Choose logo**. It is stored in the browser on that device.

If you want the logo image included in the GitHub repository instead, add a file such as `assets/logo.png`. The current app lets you upload it directly in Business settings, so you do not have to edit code.

## Important limitations

- This is a frontend-only tool. Orders and settings are stored in the browser's local storage; they do not sync between devices.
- Export JSON backups regularly. Clearing browser data can delete orders.
- Do not store customer information in the public GitHub repository.
- The barcode is a visual/internal reference barcode, not a courier-issued tracking barcode. No courier API is connected.
- Thermal printing depends on printer driver settings. Select the matching paper size and print at 100% / Actual size. Test with a sample before printing live orders.
- This is a starter implementation. Review the app and test imports, print output and backup/restore before using it for daily dispatch.
