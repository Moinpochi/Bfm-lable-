/* Parcel Studio — frontend-only shipping label workspace.
   Orders/settings/logo are stored in this browser. Export a backup regularly. */
(() => {
  "use strict";
  const STORE_KEY = "parcelStudio.v1";
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const uid = () => "ord_" + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  const escapeHTML = value => String(value ?? "").replace(/[&<>"']/g, char => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[char]));
  const safeText = value => String(value ?? "").trim();
  const money = value => new Intl.NumberFormat("en-IN", { style:"currency", currency:"INR", maximumFractionDigits:2 }).format(Number(value) || 0);
  const today = () => new Date().toISOString().slice(0,10);
  const defaultState = () => ({
    orders: [],
    printedIds: [],
    settings: { businessName:"", businessPhone:"", businessAddress:"", businessCountry:"India", logoData:"" },
    design: { template:"standard", accentColor:"#6558e8", fontScale:16, showSender:true, showBarcode:true, showNote:true, labelSize:"thermal" }
  });
  let state = loadState();
  let pendingImport = [];
  let currentLogoData = state.settings.logoData || "";
  let toastTimer = null;

  function loadState() {
    try {
      const saved = localStorage.getItem(STORE_KEY);
      if (!saved) return defaultState();
      const parsed = JSON.parse(saved);
      return { ...defaultState(), ...parsed, settings:{...defaultState().settings, ...(parsed.settings||{})}, design:{...defaultState().design, ...(parsed.design||{})}, orders:Array.isArray(parsed.orders)?parsed.orders:[], printedIds:Array.isArray(parsed.printedIds)?parsed.printedIds:[] };
    } catch (error) {
      console.warn("Could not load saved data", error);
      return defaultState();
    }
  }
  function saveState() {
    try { localStorage.setItem(STORE_KEY, JSON.stringify(state)); return true; }
    catch (error) { toast("Browser storage is full. Export a backup and use a smaller logo image.", "error"); return false; }
  }
  function toast(message, type = "success") {
    const region = $("#toastRegion");
    const node = document.createElement("div");
    node.className = "toast" + (type === "error" ? " error" : "");
    node.innerHTML = `<i data-lucide="${type === "error" ? "alert-circle" : "check-circle-2"}"></i><span>${escapeHTML(message)}</span>`;
    region.appendChild(node);
    if (window.lucide) lucide.createIcons({root:node});
    setTimeout(() => node.remove(), 3400);
  }
  function renderIcons(root = document) { if (window.lucide) lucide.createIcons({root}); }
  function initials(name) { return safeText(name).split(/\s+/).slice(0,2).map(part=>part[0]||"").join("").toUpperCase() || "—"; }
  function findOrder(id) { return state.orders.find(order => order.id === id); }

  function navigate(viewName) {
    const valid = ["overview","orders","designer","bulk","print","settings"];
    if (!valid.includes(viewName)) viewName = "overview";
    $$(".view").forEach(view => view.classList.toggle("active-view", view.id === `view-${viewName}`));
    $$(".nav-link[data-view]").forEach(link => link.classList.toggle("active", link.dataset.view === viewName));
    $("#breadcrumbTitle").textContent = ({overview:"Overview",orders:"Orders",designer:"Label studio",bulk:"Bulk import",print:"Print center",settings:"Business settings"})[viewName];
    $("#sidebar").classList.remove("open");
    if (viewName === "designer") { renderDesignerControls(); renderLabelPreview(); }
    if (viewName === "print") { renderPrintList(); renderPrintPreview(); }
    if (viewName === "orders") renderOrders();
    window.scrollTo({top:0,behavior:"smooth"});
    renderIcons();
  }
  $$("[data-view]").forEach(button => button.addEventListener("click", () => navigate(button.dataset.view)));
  $$("[data-go]").forEach(button => button.addEventListener("click", () => navigate(button.dataset.go)));
  $("#mobileMenu").addEventListener("click", () => $("#sidebar").classList.toggle("open"));
  $("#helpButton").addEventListener("click", openHelp);
  $("#topHelp").addEventListener("click", openHelp);
  $("#closeModal").addEventListener("click", closeHelp);
  $("#modalOkay").addEventListener("click", closeHelp);
  $("#modalBackdrop").addEventListener("click", event => { if(event.target.id==="modalBackdrop") closeHelp(); });
  function openHelp() {
    $("#modalTitle").textContent = "Quick guide";
    $("#modalText").textContent = "1. Add orders manually or import a CSV. 2. Save your business name and return address in Business settings. 3. Pick a template in Label Studio. 4. Select orders in Print Center and print at 100% / Actual size. This is a frontend-only tool: it does not create courier-issued tracking numbers.";
    $("#modalBackdrop").hidden = false;
    renderIcons();
  }
  function closeHelp() { $("#modalBackdrop").hidden = true; }

  function orderAddress(order) {
    return [order.address1, order.address2, [order.city, order.state, order.pincode].filter(Boolean).join(", "), order.country].filter(Boolean).join("\n");
  }
  function makeBarcodeMarkup(value) {
    const chars = safeText(value || "ORDER").split("");
    let seed = 0;
    for (const ch of chars) seed = (seed * 31 + ch.charCodeAt(0)) >>> 0;
    let bits = "101";
    for (let i=0;i<chars.length;i++) {
      const code = chars[i].charCodeAt(0);
      for (let b=0;b<7;b++) bits += ((code >> (b%7)) & 1) ? "110" : "10";
      bits += (i%2 ? "10" : "110");
    }
    bits += "101";
    let html = "";
    for (let i=0;i<bits.length;i++) if(bits[i]==="1") html += `<span style="width:${(i%5===0)?2:1}px"></span>`; else html += `<span style="width:1px;background:transparent"></span>`;
    return html;
  }
  function getLogoMarkup() {
    if (currentLogoData) return `<img class="label-logo" src="${currentLogoData}" alt="Business logo">`;
    const brandInitial = initials(state.settings.businessName || "B");
    return `<span class="label-logo-fallback">${escapeHTML(brandInitial[0] || "B")}</span>`;
  }
  function renderLabel(order, options = {}) {
    const settings = state.settings;
    const design = { ...state.design, ...options };
    const template = design.template || "standard";
    const color = design.accentColor || "#6558e8";
    const isA4 = design.labelSize === "a4";
    const showSender = design.showSender !== false;
    const showBarcode = design.showBarcode !== false;
    const showNote = design.showNote !== false;
    const recipient = order || {
      customerName:"Customer name", phone:"Phone number", orderReference:"ORDER-0001",
      address1:"House / street address", address2:"Area or landmark", city:"City", state:"State", pincode:"000000", country:"India",
      paymentType:"Prepaid", codAmount:"", deliveryNote:"Delivery instructions"
    };
    const isCod = template === "cod" || recipient.paymentType === "COD";
    const businessName = settings.businessName || "Your business name";
    const senderAddress = [settings.businessAddress, settings.businessPhone ? `Phone: ${settings.businessPhone}` : ""].filter(Boolean).join(" · ");
    const note = safeText(recipient.deliveryNote);
    return `<article class="shipping-label ${isA4 ? "a4-preview" : ""} ${template === "branded" ? "label-branded" : ""}" style="--label-accent:${escapeHTML(color)};--address-font:${Number(design.fontScale)||16}px">
      <div class="label-brand-row">${getLogoMarkup()}<div class="label-business"><strong>${escapeHTML(businessName)}</strong><small>PARCEL DISPATCH</small></div><div class="label-kind">${template === "cod" ? "COD SHIPMENT" : template === "branded" ? "BUSINESS PARCEL" : "SHIPPING LABEL"}</div></div>
      ${showSender ? `<div class="label-sender"><b>FROM / RETURN ADDRESS</b>${escapeHTML(senderAddress || "Add sender details in Business settings.")}</div>` : ""}
      <div class="label-recipient"><div class="label-overline">SHIP TO</div><div class="label-recipient-name">${escapeHTML(recipient.customerName || "Customer name")}</div><div class="label-address" style="font-size:var(--address-font)">${escapeHTML(orderAddress(recipient) || "Recipient address")}</div><div class="label-phone">${escapeHTML(recipient.phone || "Phone number")}</div>
      ${showNote && note ? `<div class="label-note">${escapeHTML(note)}</div>` : ""}
      </div>
      ${isCod ? `<div class="label-cod"><span>CASH ON DELIVERY</span><strong>${money(recipient.codAmount)}</strong></div>` : ""}
      <div class="label-bottom"><div class="label-order-line"><span>ORDER REFERENCE</span><span>${escapeHTML(recipient.orderReference || "ORDER-0001")}</span></div>
      ${showBarcode ? `<div class="label-barcode" aria-label="Decorative internal order barcode">${makeBarcodeMarkup(recipient.orderReference || "ORDER-0001")}</div><div class="label-barcode-caption">${escapeHTML(recipient.orderReference || "ORDER-0001")}</div>` : ""}
      <div class="label-footer-note">Please handle with care · Thank you</div></div>
    </article>`;
  }

  function renderDesignerControls() {
    $("#designerOrder").innerHTML = state.orders.length
      ? state.orders.map(order=>`<option value="${escapeHTML(order.id)}">${escapeHTML(order.orderReference)} — ${escapeHTML(order.customerName)}</option>`).join("")
      : `<option value="">Sample preview (no saved orders)</option>`;
    const design = state.design;
    $$("[data-template]").forEach(button=>button.classList.toggle("selected",button.dataset.template===design.template));
    $("#labelSize").value = design.labelSize || "thermal";
    $("#accentColor").value = design.accentColor || "#6558e8";
    $("#fontScale").value = design.fontScale || 16;
    $("#fontScaleValue").value = `${design.fontScale || 16} px`;
    $("#showSender").checked = design.showSender !== false;
    $("#showBarcode").checked = design.showBarcode !== false;
    $("#showNote").checked = design.showNote !== false;
  }
  function renderLabelPreview() {
    const selectedId = $("#designerOrder").value;
    const order = findOrder(selectedId) || state.orders[0] || null;
    $("#labelPreview").outerHTML = renderLabel(order, state.design).replace('<article class="shipping-label','<article id="labelPreview" class="shipping-label');
    $("#previewFormat").textContent = (state.design.labelSize === "a4" ? "A4 PAGE" : "THERMAL LABEL");
    $("#previewStage").style.minHeight = state.design.labelSize === "a4" ? "560px" : "490px";
    renderIcons();
  }
  $$("[data-template]").forEach(button => button.addEventListener("click", () => {
    state.design.template = button.dataset.template; saveState(); renderDesignerControls(); renderLabelPreview();
  }));
  $("#designerOrder").addEventListener("change", renderLabelPreview);
  $("#labelSize").addEventListener("change", event => { state.design.labelSize = event.target.value; saveState(); renderLabelPreview(); });
  $("#accentColor").addEventListener("input", event => { state.design.accentColor = event.target.value; renderLabelPreview(); });
  $("#accentColor").addEventListener("change", saveState);
  $("#resetColor").addEventListener("click", () => { state.design.accentColor="#6558e8"; saveState(); renderDesignerControls(); renderLabelPreview(); });
  $("#fontScale").addEventListener("input", event => { state.design.fontScale=Number(event.target.value); $("#fontScaleValue").value=`${event.target.value} px`; renderLabelPreview(); });
  $("#fontScale").addEventListener("change", saveState);
  ["showSender","showBarcode","showNote"].forEach(id => $(`#${id}`).addEventListener("change", event => { state.design[id]=event.target.checked; saveState(); renderLabelPreview(); }));
  $("#refreshPreview").addEventListener("click", () => { renderLabelPreview(); toast("Preview refreshed."); });
  $("#saveTemplate").addEventListener("click", () => { saveState(); toast("Your design settings are saved in this browser."); });

  function resetOrderForm() {
    $("#orderForm").reset();
    $("#editOrderId").value = "";
    $("#country").value = state.settings.businessCountry || "India";
    $("#orderFormTitle").textContent = "Create an order";
    $("#orderReference").value = suggestReference();
  }
  function suggestReference() {
    let next = state.orders.length + 1;
    let reference = `ORD-${String(next).padStart(4,"0")}`;
    while (state.orders.some(order => order.orderReference.toLowerCase() === reference.toLowerCase())) {
      next++; reference = `ORD-${String(next).padStart(4,"0")}`;
    }
    return reference;
  }
  $("#newOrderButton").addEventListener("click", () => { resetOrderForm(); $("#customerName").focus(); });
  $("#emptyNewOrder").addEventListener("click", () => { resetOrderForm(); $("#customerName").focus(); });
  $("#resetOrderForm").addEventListener("click", resetOrderForm);
  $("#paymentType").addEventListener("change", event => { $("#codAmount").disabled = event.target.value !== "COD"; if(event.target.value !== "COD") $("#codAmount").value=""; });
  $("#paymentType").dispatchEvent(new Event("change"));

  $("#orderForm").addEventListener("submit", event => {
    event.preventDefault();
    const existingId = $("#editOrderId").value;
    const order = {
      id: existingId || uid(),
      customerName:safeText($("#customerName").value), phone:safeText($("#customerPhone").value),
      orderReference:safeText($("#orderReference").value), address1:safeText($("#address1").value), address2:safeText($("#address2").value),
      city:safeText($("#city").value), state:safeText($("#state").value), pincode:safeText($("#pincode").value), country:safeText($("#country").value)||"India",
      paymentType:$("#paymentType").value, codAmount:$("#paymentType").value==="COD" ? Number($("#codAmount").value)||0 : 0,
      weight:Number($("#weight").value)||"", packageType:$("#packageType").value, deliveryNote:safeText($("#deliveryNote").value),
      updatedAt:new Date().toISOString()
    };
    if (!/^\d{6}$/.test(order.pincode)) { toast("Enter a valid 6-digit PIN code.", "error"); $("#pincode").focus(); return; }
    const duplicate = state.orders.find(item=>item.orderReference.toLowerCase()===order.orderReference.toLowerCase() && item.id!==order.id);
    if (duplicate) { toast("That order reference already exists. Use a unique reference.", "error"); $("#orderReference").focus(); return; }
    if (existingId) state.orders = state.orders.map(item=>item.id===existingId?{...item,...order}:item);
    else { order.createdAt = new Date().toISOString(); state.orders.unshift(order); }
    saveState(); resetOrderForm(); renderAll(); toast(existingId ? "Order updated." : "Order saved successfully."); navigate("orders");
  });

  function renderOrders() {
    const query = safeText($("#orderSearch").value).toLowerCase();
    const filter = $("#orderFilter").value;
    const visible = state.orders.filter(order => (filter==="all" || order.paymentType===filter) && [order.customerName,order.phone,order.orderReference,order.pincode].some(value=>String(value||"").toLowerCase().includes(query)));
    $("#orderListSub").textContent = `${state.orders.length} order${state.orders.length===1?"":"s"} in your workspace.`;
    $("#ordersTableBody").innerHTML = visible.map(order=>`<tr><td><div class="table-person"><span class="person-avatar">${escapeHTML(initials(order.customerName))}</span><span><strong>${escapeHTML(order.customerName)}</strong><small>${escapeHTML(order.city)}, ${escapeHTML(order.pincode)}</small></span></div></td><td><strong>${escapeHTML(order.orderReference)}</strong></td><td><span class="payment-pill ${order.paymentType==="COD"?"cod":""}">${escapeHTML(order.paymentType)}</span></td><td><div class="row-actions"><button class="row-action" data-action="preview" data-id="${escapeHTML(order.id)}" title="Preview label"><i data-lucide="eye"></i></button><button class="row-action" data-action="edit" data-id="${escapeHTML(order.id)}" title="Edit order"><i data-lucide="pencil"></i></button><button class="row-action" data-action="delete" data-id="${escapeHTML(order.id)}" title="Delete order"><i data-lucide="trash-2"></i></button></div></td></tr>`).join("");
    $("#ordersEmpty").style.display = visible.length ? "none" : "block";
    $("#ordersTableBody").closest(".table-wrap").style.display = visible.length ? "block" : "none";
    renderIcons();
  }
  $("#orderSearch").addEventListener("input", renderOrders);
  $("#orderFilter").addEventListener("change", renderOrders);
  $("#ordersTableBody").addEventListener("click", event => {
    const button = event.target.closest("[data-action]");
    if (!button) return;
    const order = findOrder(button.dataset.id);
    if (!order) return;
    if (button.dataset.action==="edit") editOrder(order);
    if (button.dataset.action==="preview") { $("#designerOrder").value=order.id; navigate("designer"); setTimeout(()=>{ $("#designerOrder").value=order.id; renderLabelPreview(); },0); }
    if (button.dataset.action==="delete") {
      if (!confirm(`Delete order ${order.orderReference}? This cannot be undone unless you have a backup.`)) return;
      state.orders=state.orders.filter(item=>item.id!==order.id); state.printedIds=state.printedIds.filter(id=>id!==order.id); saveState(); renderAll(); toast("Order deleted.");
    }
  });
  function editOrder(order) {
    navigate("orders");
    $("#editOrderId").value=order.id; $("#orderFormTitle").textContent="Edit order";
    const mapping={customerName:"customerName",customerPhone:"phone",orderReference:"orderReference",address1:"address1",address2:"address2",city:"city",state:"state",pincode:"pincode",country:"country",paymentType:"paymentType",codAmount:"codAmount",weight:"weight",packageType:"packageType",deliveryNote:"deliveryNote"};
    Object.entries(mapping).forEach(([id,key])=>{ $(`#${id}`).value=order[key] ?? ""; });
    $("#paymentType").dispatchEvent(new Event("change"));
    $("#orderFormPanel").scrollIntoView({behavior:"smooth",block:"start"});
  }

  function renderDashboard() {
    $("#totalOrders").textContent=state.orders.length;
    $("#totalLabels").textContent=state.orders.length;
    $("#printedCount").textContent=state.printedIds.length;
    $("#codValue").textContent=money(state.orders.filter(order=>order.paymentType==="COD").reduce((sum,order)=>sum+(Number(order.codAmount)||0),0));
    $("#navOrderCount").textContent=state.orders.length;
    $("#settingsOrderCount").textContent=state.orders.length;
    $("#settingsPrintedCount").textContent=state.printedIds.length;
    $("#todayLabel").textContent=new Intl.DateTimeFormat("en-IN",{day:"numeric",month:"short",year:"numeric"}).format(new Date());
    const recent=state.orders.slice(0,4);
    $("#recentOrders").innerHTML=recent.length?recent.map(order=>`<div class="recent-item"><span class="person-avatar">${escapeHTML(initials(order.customerName))}</span><span class="recent-main"><strong>${escapeHTML(order.customerName)}</strong><small>${escapeHTML(order.orderReference)} · ${escapeHTML(order.city)}</small></span><span class="payment-pill ${order.paymentType==="COD"?"cod":""}">${escapeHTML(order.paymentType)}</span></div>`).join(""):`<div class="empty-small">No orders yet. Create your first order to get started.</div>`;
  }

  function parseCSV(text) {
    const rows=[]; let row=[], field="", quoted=false;
    text = text.replace(/^\uFEFF/,"");
    for(let i=0;i<text.length;i++){
      const ch=text[i], next=text[i+1];
      if(ch==='"' && quoted && next==='"'){field+='"';i++;}
      else if(ch==='"'){quoted=!quoted;}
      else if(ch==="," && !quoted){row.push(field);field="";}
      else if((ch==="\n"||ch==="\r")&&!quoted){if(ch==="\r"&&next==="\n")i++;row.push(field);if(row.some(cell=>cell.trim()!==""))rows.push(row);row=[];field="";}
      else field+=ch;
    }
    if(field.length||row.length){row.push(field);if(row.some(cell=>cell.trim()!==""))rows.push(row);}
    if(!rows.length) return [];
    const headers=rows.shift().map(header=>header.trim().toLowerCase().replace(/[\s-]+/g,"_"));
    return rows.map((values,index)=>{const object={_row:index+2};headers.forEach((header,i)=>object[header]=(values[i]||"").trim());return object;});
  }
  function normalizeImportRow(row) {
    const pick=(...keys)=>{for(const key of keys){if(row[key]!==undefined&&row[key]!==null&&String(row[key]).trim()!=="")return String(row[key]).trim();}return "";};
    const payment=pick("payment_type","payment","mode").toUpperCase()==="COD"?"COD":"Prepaid";
    return {
      _row:row._row||0,
      customerName:pick("customer_name","customer","name","recipient_name"),
      phone:pick("phone","phone_number","mobile","mobile_number"),
      orderReference:pick("order_reference","order_id","order_ref","reference","order"),
      address1:pick("address1","address_line_1","address","street"),
      address2:pick("address2","address_line_2","landmark","area"),
      city:pick("city","town"),state:pick("state","region"),pincode:pick("pincode","pin_code","postal_code","zip"),
      country:pick("country")||"India",paymentType:payment,codAmount:Number(pick("cod_amount","cod","amount"))||0,
      weight:Number(pick("weight","weight_kg"))||"",packageType:pick("package_type")||"Parcel",deliveryNote:pick("delivery_note","note","instructions")
    };
  }
  function checkImportRow(order) {
    const missing=[];
    if(!order.customerName)missing.push("customer name");
    if(!order.phone)missing.push("phone");
    if(!order.orderReference)missing.push("order reference");
    if(!order.address1)missing.push("address");
    if(!order.city)missing.push("city");
    if(!order.state)missing.push("state");
    if(!/^\d{6}$/.test(order.pincode))missing.push("6-digit PIN");
    if(state.orders.some(saved=>saved.orderReference.toLowerCase()===order.orderReference.toLowerCase()))missing.push("duplicate order reference");
    return missing;
  }
  function showImportPreview() {
    const panel=$("#importPreviewPanel"); panel.hidden=!pendingImport.length;
    const valid=pendingImport.filter(row=>row.errors.length===0).length;
    $("#validCount").textContent=valid;
    $("#importRows").disabled=valid===0;
    $("#importPreviewSub").textContent=`${pendingImport.length} rows found · ${valid} valid · ${pendingImport.length-valid} need attention`;
    $("#importStatus").textContent=valid?`${valid} VALID ROWS`:"CHECK YOUR FILE";
    $("#importStatus").className="step-pill "+(valid?"import-status-good":"import-status-bad");
    $("#importPreviewBody").innerHTML=pendingImport.slice(0,100).map(row=>`<tr><td>${row._row}</td><td>${escapeHTML(row.customerName||"—")}<small style="display:block;color:#9a9cac;margin-top:3px">${escapeHTML(row.errors.join(", "))}</small></td><td>${escapeHTML(row.orderReference||"—")}</td><td><span class="payment-pill ${row.errors.length?"cod":""}">${row.errors.length?"Needs attention":"Ready"}</span></td></tr>`).join("");
    if(pendingImport.length>100) $("#importPreviewSub").textContent+=` · showing first 100`;
  }
  async function handleSpreadsheet(file) {
    if(!file)return;
    $("#bulkMessage").className="bulk-message"; $("#bulkMessage").textContent="";
    if(file.size>5*1024*1024){$("#bulkMessage").className="bulk-message error";$("#bulkMessage").textContent="File is over 5 MB. Please split it into smaller files.";return;}
    try{
      let rows;
      if(/\.csv$/i.test(file.name)||file.type==="text/csv"){
        rows=parseCSV(await file.text());
      } else if(/\.(xlsx|xls)$/i.test(file.name)){
        if(!window.XLSX){$("#bulkMessage").className="bulk-message error";$("#bulkMessage").textContent="Excel support is not loaded. Please save your sheet as CSV and upload it again.";return;}
        const data=await file.arrayBuffer();const workbook=XLSX.read(data,{type:"array"});const first=workbook.Sheets[workbook.SheetNames[0]];const json=XLSX.utils.sheet_to_json(first,{defval:""});rows=json.map((row,index)=>{const normalized={_row:index+2};Object.entries(row).forEach(([key,value])=>normalized[key.trim().toLowerCase().replace(/[\s-]+/g,"_")]=String(value??"").trim());return normalized;});
      } else {throw new Error("Please choose a CSV or Excel file.");}
      if(!rows.length)throw new Error("No order rows found. Check that your file has a header row and order data.");
      pendingImport=rows.map(row=>{const normalized=normalizeImportRow(row);return {...normalized,_row:row._row,errors:checkImportRow(normalized)};});
      showImportPreview();
      $("#bulkMessage").className="bulk-message success";
      $("#bulkMessage").textContent=`Loaded ${rows.length} row${rows.length===1?"":"s"} from ${file.name}. Review the validation results before importing.`;
      $("#importPreviewPanel").scrollIntoView({behavior:"smooth",block:"nearest"});
    }catch(error){$("#bulkMessage").className="bulk-message error";$("#bulkMessage").textContent=error.message||"Could not read this file.";}
  }
  $("#dropZone").addEventListener("click",()=>$("#csvFile").click());
  $("#dropZone").addEventListener("keydown",event=>{if(event.key==="Enter"||event.key===" "){event.preventDefault();$("#csvFile").click();}});
  $("#csvFile").addEventListener("change",event=>handleSpreadsheet(event.target.files[0]));
  $("#dropZone").addEventListener("dragover",event=>{event.preventDefault();$("#dropZone").classList.add("drag-over");});
  $("#dropZone").addEventListener("dragleave",()=>$("#dropZone").classList.remove("drag-over"));
  $("#dropZone").addEventListener("drop",event=>{event.preventDefault();$("#dropZone").classList.remove("drag-over");handleSpreadsheet(event.dataTransfer.files[0]);});
  $("#importRows").addEventListener("click",()=>{
    const valid=pendingImport.filter(row=>row.errors.length===0);
    if(!valid.length)return;
    const imported=valid.map(row=>({id:uid(),customerName:row.customerName,phone:row.phone,orderReference:row.orderReference,address1:row.address1,address2:row.address2,city:row.city,state:row.state,pincode:row.pincode,country:row.country,paymentType:row.paymentType,codAmount:row.codAmount,weight:row.weight,packageType:row.packageType,deliveryNote:row.deliveryNote,createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()}));
    state.orders=[...imported,...state.orders];saveState();pendingImport=[];$("#csvFile").value="";$("#importPreviewPanel").hidden=true;$("#bulkMessage").className="bulk-message success";$("#bulkMessage").textContent=`Imported ${imported.length} order${imported.length===1?"":"s"} successfully.`;renderAll();toast(`${imported.length} orders imported.`);
  });
  $("#downloadSample").addEventListener("click",()=>{
    const csv="customer_name,phone,order_reference,address1,address2,city,state,pincode,country,payment_type,cod_amount,weight,package_type,delivery_note\nAyesha Patel,+919876543210,BFM-1001,12 Market Road,Near City Mall,Ahmedabad,Gujarat,380001,India,COD,799,0.5,Parcel,Call on arrival\nRahul Shah,+919812345678,BFM-1002,44 Station Road,,Rajkot,Gujarat,360001,India,Prepaid,0,1.2,Food product,\n";
    downloadBlob(new Blob([csv],{type:"text/csv;charset=utf-8;"}),"shipping-orders-sample.csv");
  });

  function renderPrintList() {
    $("#printOrderList").innerHTML=state.orders.length?state.orders.map(order=>`<label class="print-order-item"><input type="checkbox" value="${escapeHTML(order.id)}" ${selectedPrintIds.has(order.id)?"checked":""}/><span><strong>${escapeHTML(order.customerName)}</strong><small>${escapeHTML(order.orderReference)} · ${escapeHTML(order.city)}</small></span><em>${escapeHTML(order.paymentType)}</em></label>`).join(""):`<div class="empty-small">No orders to print. Add an order first.</div>`;
    $$('input[type="checkbox"]',$("#printOrderList")).forEach(input=>input.addEventListener("change",()=>{if(input.checked)selectedPrintIds.add(input.value);else selectedPrintIds.delete(input.value);renderPrintPreview();}));
    updateFormatCards();
  }
  let selectedPrintIds = new Set();
  function selectedPrintOrders() { return state.orders.filter(order=>selectedPrintIds.has(order.id)); }
  function printOptions() {
    return { template:$("#printTemplate").value, labelSize:$('input[name="printFormat"]:checked').value, accentColor:state.design.accentColor, fontScale:state.design.fontScale, showSender:state.design.showSender, showBarcode:state.design.showBarcode, showNote:state.design.showNote };
  }
  function updateFormatCards() {
    $$(".format-card").forEach(card=>card.classList.toggle("selected",card.querySelector("input").checked));
    $("#printSummaryFormat").textContent=$('input[name="printFormat"]:checked').value==="a4"?"A4 paper":"Thermal";
  }
  function renderPrintPreview() {
    const orders=selectedPrintOrders(), options=printOptions();
    $("#selectedCount").textContent=`${orders.length} selected`;
    $("#printSummaryCount").textContent=orders.length;
    $("#printPreviewCount").textContent=`${orders.length} label${orders.length===1?"":"s"}`;
    $("#printSummaryFormat").textContent=options.labelSize==="a4"?"A4 paper":"Thermal";
    if(!orders.length) $("#printPreviewStage").innerHTML=`<div class="empty-print"><i data-lucide="printer"></i><strong>Your print preview appears here</strong><p>Select one or more orders to preview your output.</p></div>`;
    else $("#printPreviewStage").innerHTML=`<div class="print-preview-stack">${orders.slice(0,3).map(order=>renderLabel(order,options)).join("")}${orders.length>3?`<div class="print-count-chip">+ ${orders.length-3} more label${orders.length-3===1?"":"s"} in output</div>`:""}</div>`;
    renderIcons();
  }
  $$('input[name="printFormat"]').forEach(input=>input.addEventListener("change",()=>{updateFormatCards();renderPrintPreview();}));
  $("#printTemplate").addEventListener("change",renderPrintPreview);
  $("#selectAllOrders").addEventListener("click",()=>{state.orders.forEach(order=>selectedPrintIds.add(order.id));renderPrintList();renderPrintPreview();});
  $("#selectNoOrders").addEventListener("click",()=>{selectedPrintIds.clear();renderPrintList();renderPrintPreview();});
  function buildPrintDocument(orders,options) {
    const labels=orders.map(order=>renderLabel(order,options)).join("");
    const pageCSS=options.labelSize==="a4"?"@page{size:A4;margin:0}.shipping-label{width:100mm;min-height:145mm;margin:0 auto;padding:8mm;border:0;box-shadow:none;break-after:page}.shipping-label.a4-preview{width:100mm;min-height:145mm}":"@page{size:100mm 150mm;margin:0}.shipping-label{width:100mm;height:150mm;min-height:150mm;margin:0;padding:6mm;border:0;box-shadow:none;break-after:page;overflow:hidden}.shipping-label.a4-preview{width:100mm;min-height:150mm}";
    return `<!doctype html><html><head><meta charset="utf-8"><title>Shipping labels</title><style>
      *{box-sizing:border-box}html,body{margin:0;padding:0;background:#fff;color:#202132;font-family:Arial,Helvetica,sans-serif}
      ${pageCSS}
      .label-brand-row{display:flex;align-items:center;gap:3mm;border-bottom:1.5px solid var(--label-accent);padding-bottom:3mm}.label-logo{width:10mm;height:10mm;object-fit:contain}.label-logo-fallback{width:10mm;height:10mm;display:grid;place-items:center;background:var(--label-accent);color:white;font-weight:bold}.label-business{min-width:0;flex:1}.label-business strong{display:block;font-size:10pt;overflow-wrap:anywhere}.label-business small{display:block;font-size:6pt;color:#777;margin-top:1mm}.label-kind{font-size:6pt;font-weight:bold;color:var(--label-accent);text-align:right}.label-sender{padding:3mm 0;border-bottom:1px dashed #bbb;font-size:7pt;line-height:1.45;color:#555}.label-sender b{display:block;font-size:5.5pt;margin-bottom:1mm;color:#777}.label-recipient{padding:5mm 0 3mm}.label-overline{font-size:7pt;font-weight:bold;letter-spacing:1px;color:var(--label-accent);margin-bottom:2mm}.label-recipient-name{font-size:15pt;font-weight:bold;overflow-wrap:anywhere;margin-bottom:2mm}.label-address{font-size:${Number(options.fontScale)||16}px;line-height:1.35;white-space:pre-line;overflow-wrap:anywhere}.label-phone{font-size:10pt;font-weight:bold;margin-top:2mm}.label-note{font-size:8pt;margin-top:2mm;padding-left:2mm;border-left:2px solid var(--label-accent);color:#555}.label-cod{display:flex;justify-content:space-between;align-items:center;background:#fff3df;border:1px solid #f1d6a6;padding:3mm;margin:2mm 0}.label-cod span{font-size:7pt;font-weight:bold}.label-cod strong{font-size:15pt}.label-bottom{margin-top:auto;border-top:1.5px solid #222;padding-top:3mm}.label-order-line{display:flex;justify-content:space-between;gap:3mm;font-size:7pt;font-weight:bold;margin-bottom:2mm}.label-barcode{height:13mm;display:flex;align-items:stretch;justify-content:center;gap:0.3mm;overflow:hidden}.label-barcode span{display:block;background:#111;flex-shrink:0}.label-barcode-caption{text-align:center;font:7pt monospace;letter-spacing:1.5px;margin-top:1mm;overflow-wrap:anywhere}.label-footer-note{text-align:center;font-size:5.5pt;color:#777;margin-top:2mm}
      </style></head><body>${labels}</body></html>`;
  }
  function openPrintWindow(downloadOnly=false) {
    const orders=selectedPrintOrders();
    if(!orders.length){toast("Select at least one order to print.", "error");return;}
    const options=printOptions();
    const html=buildPrintDocument(orders,options);
    if(downloadOnly){
      const blob=new Blob([html],{type:"text/html;charset=utf-8"});
      const url=URL.createObjectURL(blob);
      const anchor=document.createElement("a");anchor.href=url;anchor.download=`shipping-labels-${today()}.html`;document.body.appendChild(anchor);anchor.click();anchor.remove();setTimeout(()=>URL.revokeObjectURL(url),2000);
      toast("Print layout downloaded. Open it and choose Print → Save as PDF.");
      markPrinted(orders);
      return;
    }
    const printWindow=window.open("","_blank");
    if(!printWindow){toast("Your browser blocked the print window. Allow pop-ups and try again.", "error");return;}
    printWindow.document.open();printWindow.document.write(html);printWindow.document.close();
    printWindow.onload=()=>{setTimeout(()=>{printWindow.focus();printWindow.print();},500);};
    markPrinted(orders);
  }
  function markPrinted(orders) {
    const ids=new Set([...state.printedIds,...orders.map(order=>order.id)]);
    state.printedIds=[...ids];saveState();renderDashboard();
  }
  $("#generatePrint").addEventListener("click",()=>openPrintWindow(false));
  $("#downloadPrintPdf").addEventListener("click",()=>openPrintWindow(true));

  function downloadBlob(blob,filename) {
    const url=URL.createObjectURL(blob);const anchor=document.createElement("a");anchor.href=url;anchor.download=filename;document.body.appendChild(anchor);anchor.click();anchor.remove();setTimeout(()=>URL.revokeObjectURL(url),1500);
  }
  function exportOrdersCSV() {
    const headers=["customer_name","phone","order_reference","address1","address2","city","state","pincode","country","payment_type","cod_amount","weight","package_type","delivery_note"];
    const csv=[headers.join(","),...state.orders.map(order=>headers.map(header=>{const keyMap={customer_name:"customerName",phone:"phone",order_reference:"orderReference",address1:"address1",address2:"address2",city:"city",state:"state",pincode:"pincode",country:"country",payment_type:"paymentType",cod_amount:"codAmount",weight:"weight",package_type:"packageType",delivery_note:"deliveryNote"};const value=String(order[keyMap[header]]??"");return `"${value.replace(/"/g,'""')}"`;}).join(","))].join("\r\n");
    downloadBlob(new Blob(["\uFEFF",csv],{type:"text/csv;charset=utf-8;"}),`shipping-orders-${today()}.csv`);
    toast("Orders exported as CSV.");
  }
  $("#exportOrders").addEventListener("click",exportOrdersCSV);
  function exportBackup() {
    const backup={app:"Parcel Studio",version:1,exportedAt:new Date().toISOString(),state};
    downloadBlob(new Blob([JSON.stringify(backup,null,2)],{type:"application/json"}),`parcel-studio-backup-${today()}.json`);
    toast("Backup downloaded.");
  }
  $("#exportBackup").addEventListener("click",exportBackup);
  $("#importBackupButton").addEventListener("click",()=>$("#backupInput").click());
  $("#backupInput").addEventListener("change",async event=>{
    const file=event.target.files[0];if(!file)return;
    try{
      const parsed=JSON.parse(await file.text());const incoming=parsed.state||parsed;
      if(!Array.isArray(incoming.orders)||!incoming.settings)throw new Error("This file does not look like a Parcel Studio backup.");
      if(!confirm(`Restore ${incoming.orders.length} orders from this backup? Current local data will be replaced.`))return;
      state={...defaultState(),...incoming,settings:{...defaultState().settings,...incoming.settings},design:{...defaultState().design,...incoming.design}};
      currentLogoData=state.settings.logoData||"";saveState();renderAll();toast("Backup restored.");
    }catch(error){toast(error.message||"Could not restore backup.","error");}
    finally{event.target.value="";}
  });
  $("#clearAllData").addEventListener("click",()=>{
    if(!confirm("Delete ALL orders, settings, logo and print history from this browser? Export a backup first if you need these records."))return;
    state=defaultState();currentLogoData="";selectedPrintIds.clear();saveState();resetOrderForm();renderAll();renderSettings();toast("All local data deleted.");
  });

  function renderSettings() {
    $("#businessName").value=state.settings.businessName||"";
    $("#businessPhone").value=state.settings.businessPhone||"";
    $("#businessAddress").value=state.settings.businessAddress||"";
    $("#businessCountry").value=state.settings.businessCountry||"India";
    $("#logoPreview").innerHTML=currentLogoData?`<img src="${currentLogoData}" alt="Business logo preview">`:"<span>LOGO</span>";
  }
  $("#settingsForm").addEventListener("submit",event=>{
    event.preventDefault();
    state.settings.businessName=safeText($("#businessName").value);
    state.settings.businessPhone=safeText($("#businessPhone").value);
    state.settings.businessAddress=safeText($("#businessAddress").value);
    state.settings.businessCountry=safeText($("#businessCountry").value)||"India";
    state.settings.logoData=currentLogoData;
    saveState();renderAll();renderSettings();toast("Business settings saved.");
  });
  $("#logoInput").addEventListener("change",event=>{
    const file=event.target.files[0];if(!file)return;
    if(!/^image\/(png|jpeg|webp|svg\+xml)$/.test(file.type)){toast("Choose a PNG, JPG, WebP or SVG image.","error");return;}
    if(file.size>1.5*1024*1024){toast("Please use a logo image smaller than 1.5 MB.","error");return;}
    const reader=new FileReader();
    reader.onload=()=>{currentLogoData=String(reader.result);$("#logoPreview").innerHTML=`<img src="${currentLogoData}" alt="Logo preview">`;toast("Logo selected. Save business settings to keep it.");};
    reader.readAsDataURL(file);
  });
  $("#removeLogo").addEventListener("click",()=>{currentLogoData="";state.settings.logoData="";saveState();renderSettings();toast("Logo removed.");});

  function renderAll() {
    renderDashboard();renderOrders();renderSettings();renderDesignerControls();renderLabelPreview();
    if($("#view-print").classList.contains("active-view")){renderPrintList();renderPrintPreview();}
  }

  // Restore user preference, then wire a starter reference and initial screen.
  $("#todayLabel").textContent=new Intl.DateTimeFormat("en-IN",{day:"numeric",month:"short",year:"numeric"}).format(new Date());
  $("#orderReference").value=suggestReference();
  renderSettings();
  renderAll();
  renderIcons();

  // Optional Excel support. CSV remains fully functional without this library.
  const xlsx=document.createElement("script");
  xlsx.src="https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js";
  xlsx.async=true;
  document.head.appendChild(xlsx);
})();
